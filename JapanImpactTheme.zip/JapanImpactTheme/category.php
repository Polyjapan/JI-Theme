<?php get_header(); ?>
<?php get_sidebar(); ?>
<div class="main">
	<?php get_template_part('loop'); ?>
</div>
<?php get_footer(); ?>

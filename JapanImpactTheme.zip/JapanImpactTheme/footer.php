	<footer class="site-footer">
		<p>
			@<?php echo date("Y"); ?>  <?php bloginfo('name'); ?> -   <a href="<?php bloginfo('rss2_url'); ?>">rss</a>
		</p>
	</footer>
	<?php wp_footer(); ?>
	</body>
</html>

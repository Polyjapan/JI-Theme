<!-- page accueil -->
<?php
	get_header();
	get_sidebar();
	get_template_part('loop');
	get_footer();
?>

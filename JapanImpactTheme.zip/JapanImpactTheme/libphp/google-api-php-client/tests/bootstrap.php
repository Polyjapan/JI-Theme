<?php
set_include_path(dirname(dirname(__FILE__)) . "/src"
 . PATH_SEPARATOR . get_include_path());